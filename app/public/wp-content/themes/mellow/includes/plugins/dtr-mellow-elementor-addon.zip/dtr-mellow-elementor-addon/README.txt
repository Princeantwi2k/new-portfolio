=== Mellow Elementor Addons ===
Contributors: tansh
Tags: Elementor, Addon
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Addons for premium elemetor plugin.

== Description ==
Addons for premium elemetor plugin.

== Changelog ==
= 1.0.0 =
* Initial release.

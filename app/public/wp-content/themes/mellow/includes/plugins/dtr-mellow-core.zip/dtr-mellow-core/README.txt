=== Mellow Core ===
Contributors: tansh
Tags: Shortcodes, Custom Post Types
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Creates Shortcodes, custom post types, widgets.

== Description ==

Creates Shortcodes, custom post types, widgets, social share.

== Changelog ==

= 1.0.0 =
* Initial release.